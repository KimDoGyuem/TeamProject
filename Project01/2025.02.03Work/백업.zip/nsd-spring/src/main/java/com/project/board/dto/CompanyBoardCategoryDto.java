package com.project.board.dto;

import lombok.Data;

@Data
public class CompanyBoardCategoryDto {
	private String cb_category_name;
}
